﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula4
{
    internal class Turma

    {
        public string periodo;
        public string serie;
        public string sigla;
        public string tipo;









    }
}
