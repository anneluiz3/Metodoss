﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aula4
{
    internal class Funcionarios
    {
        public string nome;
        public string cargo;
        public double salario;
    }
}
